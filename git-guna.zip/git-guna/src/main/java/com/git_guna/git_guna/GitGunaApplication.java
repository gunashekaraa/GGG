package com.git_guna.git_guna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitGunaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitGunaApplication.class, args);
	}

}
