package com.git_guna.git_guna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitGunaApplicationTests {

	@Test
	void contextLoads() {
	}

}
